﻿namespace GrimOwlRiptideClient;

class MainClass
{
    public static void Main(string[] args)
    {
    }
}