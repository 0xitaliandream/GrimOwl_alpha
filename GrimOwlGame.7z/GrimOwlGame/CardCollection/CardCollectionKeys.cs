namespace GrimOwl;
public class CardCollectionKeys
{
    public const string Deck = "Deck";
    public const string Hand = "Hand";
    public const string Board = "Board";
    public const string Graveyard = "Graveyard";
    public const string Permanent = "Permanent";
}
